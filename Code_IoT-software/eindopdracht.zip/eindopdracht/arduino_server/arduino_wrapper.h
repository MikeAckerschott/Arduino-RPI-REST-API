// filepath: c:\Users\mikea\Documents\IoT-techniek_svn\Code
// IoT-software\eindopdracht\arduino_server\led_pins.h
#ifndef ARDUINO_WRAPPER_H
#define ARDUINO_WRAPPER_H

extern const int GREEN;
extern const int YELLOW;
extern const int RED1;
extern const int RED2;

#endif