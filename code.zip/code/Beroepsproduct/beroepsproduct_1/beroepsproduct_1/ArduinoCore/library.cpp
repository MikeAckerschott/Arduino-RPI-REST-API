/*
 * ArduinoCore.cpp
 *
 * Created: 19/03/2025 15:45:38
 * Author : mikea
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

