/*
 * ArduinoCore.cpp
 *
 * Created: 20/03/2025 15:05:22
 * Author : mikea
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

